# FruitVerse AI Academy

A responsive, single-page AI video learning website built with plain HTML, CSS, and JavaScript. No frameworks, package installs, or API keys required.

## Run locally
1. Extract `fruitverse-ai-academy.zip`.
2. Open `index.html` in any modern browser.

## Free hosting with GitHub Pages
1. Sign in to GitHub and create a new **public** repository, e.g. `fruitverse-ai-academy`.
2. Upload `index.html` (and optionally this README) to the repository root.
3. Open **Settings → Pages**.
4. Under build/deployment, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the site. The Pages screen will show the live URL.

## Free hosting with Netlify Drop
1. Open https://app.netlify.com/drop in your browser.
2. Sign in if prompted.
3. Drag the folder containing `index.html` onto the page.
4. Netlify will publish a preview URL. You can rename the site in its dashboard.

## Customize
- Edit the tutorial titles and descriptions in `index.html`.
- Replace the sample prompts inside the `<pre class="prompt-body">` blocks.
- Add your own YouTube tutorial links by changing the lesson links.
- Change colors in the `:root` CSS variables at the top of the `<style>` block.

## Included features
- Responsive mobile and desktop layout
- Mobile navigation menu
- Tutorial cards and quick links
- Search and topic filtering for mini lessons
- Four copy-prompt buttons with clipboard fallback
- External AI tool links
- No external JavaScript libraries or backend needed

This is a static website. Login, user accounts, payments, analytics, and uploading lessons dynamically would need additional services/backend code.
